return {
  name = '[Hex]Vayne',
  id = '[Hex]Vayne',
  riot=true,
  flag = {
    text = '[Hex]',
    color = {
    text = 0xFFFFF700,
    background1 = 0xFFEF9AAB,
    background2 = 0xFFFF007F,
    },
   },
  load = function()
    return player.charName == 'Vayne'
  end,
}