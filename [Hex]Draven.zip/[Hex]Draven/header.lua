return {
        id = 'draven',
        name = '[Hex]Draven',
        load = function()
          return player.charName == 'Draven'
        end,
      }