return {
  name = '[Hex]Kaisa',
  id = '[Hex]Kaisa',
  flag = {
    text = '[Hex]',
    color = {
    text = 0xFFFFF700,
    background1 = 0xFFEF9AAB,
    background2 = 0xFFFF007F,
    },
   },
  load = function()
    return player.charName == 'Kaisa'
  end,
}